
package com.mycompany.coffee_hut_franchise;


public class Coffee_Hut_franchise {

    public static void main(String[] args) {
        
        // Cities and string
        // single dimensional array
        String[] cites = {
            "Cape Town"
            "Port Elizabeth"
            "Pretoria"
        };
        
    // Drinks
    // single dimensional array
       String[] drinks = {
           "Coffee"
           "Tea"
           "Boba Tea"
       };

        

    // two dimensional arrays
    // row= cities
    // colums = drinks
       int [][] sales = {
           {500, 300, 125},
           {450, 250, 100},
           {480, 175, 120},
           
       };

       //variables for finding the cities and highest sales
       // highest sales for drinks
       int highestsales = 0;
       String highestcity = "";
       
       System.out.println("highest drink sales");
       
       // calclulating the total number of sales  for each city 
       for (int i = 0; i < sales.length; i++)
       
       int total = 0;
       
       for (int j = 0;j < sales[i].length; j++){
       total= total + sales[i][j];
      
       System.out.println(cities + ":" + total );
       
       
       //check for highest cities
       if (total > highestsales){
       highestsales = total;
       highestcity = cities[i];
       
}
          
       
       
       
           
                   
       
    }
}
